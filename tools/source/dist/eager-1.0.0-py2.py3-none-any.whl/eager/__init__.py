""""
    This is a open source set of tools used to create
training sets for OpenCV Cascade Classifiers.
    It is free of charge and provided as-is. You may use 
for research and study purposes only.

    @author: Gabriel Barros 
    @author-email: gbbabarros@gmail.com
    All Rigths Reserved (2016)
"""

__version__ = '1.0.0'
