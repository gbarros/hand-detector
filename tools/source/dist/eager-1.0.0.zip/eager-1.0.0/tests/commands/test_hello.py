"""Tests for our `skele hello` subcommand."""

from unittest import TestCase


class TestHello(TestCase):
    def test_returns_multiple_lines(self):
        self.assertTrue(True)
