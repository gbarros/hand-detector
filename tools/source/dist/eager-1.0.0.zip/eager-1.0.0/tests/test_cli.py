"""Tests for our main skele CLI module."""

from unittest import TestCase


class TestHelp(TestCase):
    def test_returns_usage_information(self):
        self.assertTrue(True)
